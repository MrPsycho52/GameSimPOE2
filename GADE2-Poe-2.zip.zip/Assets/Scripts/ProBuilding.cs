﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProBuilding : Building {

    public int RRemain { get; set; }
    public string ProType { get; set; }
}
