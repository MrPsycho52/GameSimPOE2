﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map : MonoBehaviour
{
    public Building[,] map = new Building[20, 20];
    public Tile[,] units = new Tile[20, 20];

    public GameObject Barb;
    public GameObject Archer;
    public GameObject ProB;
    public GameObject FacB;
    public GameObject OpenMap;
    public GameObject NoUnit;
    public GameObject HealthBar;

    bool bSpawn = false;

    int counter = 0; 

    private void Start()
    {

        if(bSpawn == true)
        {
            counter = 0;
        }

        for (int x = 0; x < 20; x++)
        {
            for (int y = 0; y < 20; y++)
            {

                Building t = new Building();
                t.State = Building.States.OpenMap;
                t.X = x;
                t.Y = y;
                map[x, y] = t;

                Tile t1 = new Tile();
                t1.State = Tile.States.NoUnit;
                t1.X = x;
                t1.Y = y;
                units[x, y] = t1;
            }
        }
        GenerateMap();
    }

    private void GenerateMap()
    {
        GenerateUnits();
        GenerateBuildings();

        RegenerateMap();
    }

    private void Update()
    {
        counter++;

        if(counter == 60)
        {
            FacSpawnUnits();
            bSpawn = true;
            Debug.Log("Spawned New Unit");
        }

        GenerateUnits();
        MoveUnits();
    }

    private void RegenerateMap()
    {
        //Set Prefab for Array
        foreach (Building t in map)
        {
            if (t.State == Building.States.OpenMap)
            {
                Instantiate(OpenMap, new Vector3(t.X, 0f, t.Y), Quaternion.identity);
            }
        }
    }

    private void GenerateBuildings()
    {
        //Factory Building

        int newX = Random.Range(0, 20);
        int newY = Random.Range(0, 20);

        Instantiate(HealthBar, new Vector3(newX, 1f, newY), Quaternion.identity);

        Instantiate(FacB, new Vector3(newX, 0f, newY), Quaternion.identity);
        //Debug.Log("FacBmade");

        FacBuilding f = new FacBuilding();
        f.State = FacBuilding.States.FacB;
        map[newX, newY] = f;

        map[newX, newY].Hp = 150;
        map[newX, newY].Speed = 1;
        map[newX, newY].Symbol = "FB";
        map[newX, newY].Team = Random.Range(0, 1);

        //Production Building

        int newX1 = Random.Range(0, 20);
        int newY1 = Random.Range(0, 20);

        Instantiate(HealthBar, new Vector3(newX1, 1f, newY1), Quaternion.identity);

        Instantiate(ProB, new Vector3(newX1, 0f, newY1), Quaternion.identity);
        //Debug.Log("ProBmade");

        ProBuilding p = new ProBuilding();
        p.State = ProBuilding.States.FacB;
        map[newX1, newY1] = p;

        map[newX1, newY1].Hp = 150;
        map[newX1, newY1].Speed = 1;
        map[newX1, newY1].Symbol = "PB";
        map[newX1, newY1].Team = Random.Range(0, 1);

    }

    private void GenerateUnits()
    {
        //Make Starting Units

        for (int i = 0; i < 10; i++)
        {
            int newX = Random.Range(0, 20);
            int newY = Random.Range(0, 20);
            int team = i % 2;
            int tempAttack = 0;
            switch (Random.Range(0, 4))
            {
                case 0: tempAttack = 5; break;
                case 1: tempAttack = 10; break;
                case 2: tempAttack = 15; break;
                case 3: tempAttack = 20; break;
            }
            switch (Random.Range(0, 2))
            {
                case 0:
                    units[newX, newY].State = Tile.States.Barb;
                    units[newX, newY].attack = tempAttack;
                    units[newX, newY].health = 100;
                    units[newX, newY].speed = 1;
                    units[newX, newY].range = 1;
                    units[newX, newY].Symbol = "Bar";
                    units[newX, newY].Team = team;
                    // Instantiate(Barb, new Vector3(newX, 0f, newY), Quaternion.identity);
                    break;
                case 1:
                    units[newX, newY].State = Tile.States.Archer;
                    units[newX, newY].attack = tempAttack;
                    units[newX, newY].health = 50;
                    units[newX, newY].speed = 2;
                    units[newX, newY].range = 2;
                    units[newX, newY].Symbol = "Ar";
                    units[newX, newY].Team = team;

                    // Instantiate(Archer, new Vector3(newX, 0f, newY), Quaternion.identity);
                    break;
            }
            
        } 
        foreach (Tile t in units)
            if (t.State == Tile.States.Barb)
            {
                Instantiate(HealthBar,new Vector3(t.X, 1f, t.Y), Quaternion.identity);

                Instantiate(Barb, new Vector3(t.X, 0f, t.Y), Quaternion.identity);
            }
            else if (t.State == Tile.States.Archer)
            {
                Debug.Log("ArcherMade");
                Instantiate(HealthBar, new Vector3(t.X, 1f, t.Y), Quaternion.identity);
                Instantiate(Archer, new Vector3(t.X, 0f, t.Y), Quaternion.identity);
            }
            else if (t.State == Tile.States.NoUnit)
            {
                Debug.Log("NoUnitFound");
            }
    }
    

    public void MoveUnits()
    {
        Debug.Log("Checker0");
        int newX = 0;
        int newY = 0;

        foreach (Tile t in units)
        {
            if ((t.State == Tile.States.Barb || t.State == Tile.States.Archer))
            {
                if (t.X >= 0 && t.X <= 18 && t.Y >= 0 && t.Y <= 18)
                {
                    Debug.Log("Checker1");
                    units[t.X, t.Y].State = Tile.States.NoUnit;
                    newX = t.X + 1;
                    newY = t.Y + 1;
                }
                else if (t.X < 0 || t.X > 19 && t.Y < 0 || t.Y >= 19)
                {
                    Debug.Log("Checker2");
                    units[t.X, t.Y].State = Tile.States.NoUnit;
                    newX = 1;
                    newY = 1;
                }
            }

           //units[t.X, t.Y].State = Tile.States.NoUnit;

            if (t.State == Tile.States.Barb)
            {
                Debug.Log("Barberian: " + t.X + " " + t.Y + " " + newX + " " + newY);
              //  units[t.X, t.Y].State = Tile.States.NoUnit;
                units[newX, newY].State = Tile.States.Barb;

            }
            else if (t.State == Tile.States.Archer)
            {
                Debug.Log("Archer: " + t.X + " " + t.Y + " " + newX + " " + newY);
                //units[t.X, t.Y].State = Tile.States.NoUnit;
                units[newX, newY].State = Tile.States.Archer;

            }
        }
    }

    private void FacSpawnUnits()
    {
        foreach (Building f in map)
        {
            if ((f.State == Building.States.FacB))
            {
                f.X = f.X + 1;
                f.Y = f.Y + 1;

                switch (Random.Range(0, 1))
                {
                    case 0:
                        units[f.X, f.Y].State = Tile.States.Barb;
                        break;
                    case 1:
                        units[f.X, f.Y].State = Tile.States.Archer;
                        break;
                }
            }
        }
    }

    private void GenerateResources()
    {

    }
}
