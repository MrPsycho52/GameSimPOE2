﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Building
{
    public enum States {FacB, ProB, OpenMap};

    public States State { get; set; }
    public int X { get; set; }
    public int Y { get; set; }
    public int Hp { get; set; }
    public int Speed { get; set; }
    public int Team { get; set; }
    public string Symbol { get; set; }
}
