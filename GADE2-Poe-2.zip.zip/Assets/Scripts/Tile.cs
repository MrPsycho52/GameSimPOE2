﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile
{
    public enum States { Barb,Archer, NoUnit };

    public States State { get; set; }
    public int x { get; set; }
    public int y { get; set; }
    public int attack { get; set; }
    public int health { get; set; }
    public int range { get; set; }
    public int speed { get; set; }
    public int team { get; set; }
    public string symbol { get; set; }

    public int Attack
    {
        get { return attack; }
        set { attack = value; }
    }

    public int X
    {
        get { return x; }
        set { x = value; }
    }

    public int Y
    {
        get { return y; }
        set { y = value; }
    }

    public string Symbol
    {
        get { return symbol; }
        set { symbol = value; }
    }

    public int Team
    {
        get { return team; }
        set { team = value; }
    }

    public void MoveUnit(ref Tile closestUnit)
        {
            //No unit closest - last reminaing unit 
            if(this == closestUnit)
            {
                return;
            }

            //only react to enemy units
            if (closestUnit.Team != team)
            {
                //combat
                if (health < 25) //run away
                {
                    switch (Random.Range(0,2))
                    {
                        case 0: x += (1 * speed); break;
                        case 1: x -= (1 * speed); break;
                    }

                    switch (Random.Range(0, 2))
                {
                        case 0: y += (1 * speed); break;
                        case 1: y -= (1 * speed); break;
                    }

                    //check bounds
                    if(x <= 0)
                    {
                        x = 0;
                    }
                    else if(x >= 20)
                    {
                        x = 20;
                    }

                    if(y <= 0)
                    {
                        y = 0;
                    }
                    else if(y >= 20)
                    {
                        y = 20;
                    }

                }
                else if(System.Math.Abs(x - closestUnit.X) <= speed && System.Math.Abs(y - closestUnit.Y) <= speed) //check if in combat
                {
                    Combat(ref closestUnit);
                }
                else //move towards closest unit    
                {
                    if (x > closestUnit.X)
                    {
                        x -= speed;
                    }
                    else if (x < closestUnit.X)
                    {
                        x += speed;
                    }

                    if (y > closestUnit.Y)
                    {
                        y -= speed;
                    }
                    else if (y < closestUnit.Y)
                    {
                        y += speed;
                    }
                }
            }
        }

        public void Combat(ref Tile attacker)
        {
            this.health = this.health - attacker.Attack;
            if(health <= 0)
            {
                Death();
            }
        }
    public void Death()
    {
        Debug.Log("A unit Died");
    }

    public bool InRange(ref Tile attacker)
        {
            
            if(DistanceTo(attacker) == range)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private int DistanceTo(Tile unit)
        {
        int ireturn = 0;
            int dx = System.Math.Abs(unit.X - x);
            int dy = System.Math.Abs(unit.Y - y);
            double part = (dx * dx) + (dy * dy);
         //   int ireturn = System.Math.Sqrt(part);
        return ireturn;
        }

        public Tile Closest(ref Tile[] map)
        {
            Tile closest = this;
            int smallestRange = 100;
            foreach(Tile u in map)
            {
                if (u.Team != team)
                {
                    if (smallestRange > DistanceTo(u) && u != this)
                    {
                        smallestRange = DistanceTo(u);
                        closest = u;
                    }
                }
            }
            return closest;
        }
}
