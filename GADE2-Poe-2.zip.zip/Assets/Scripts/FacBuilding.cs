﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FacBuilding : Building {

    public int SpawnPointX { get; set; }
    public int SpawnPointY { get; set; }
    public Tile UnitType { get; set; }
}
